Ciao dal mio primo repo AI!
