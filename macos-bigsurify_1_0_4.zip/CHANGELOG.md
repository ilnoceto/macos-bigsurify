# macos-bigsurify – Changelog

## v1.0.4 (2025-08-03)
- Pacchetto completo 100% offline
- Inclusi tutti i temi WhiteSur e Papirus
- Cursori Apple
- Sfondi macOS
- Script Bash & Python per installazione/restore/utilità
- Ambiente Python portabile (python_env/)
- Documentazione bilingue (IT/EN)
- Licenza MIT + nota personale

## v1.0.3 e precedenti
- Versioni precedenti non ufficialmente documentate
