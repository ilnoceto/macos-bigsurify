#!/usr/bin/env python3
print("Benvenuto nello script utility di macos-bigsurify!")
print("Aggiungi qui le tue funzioni personalizzate.")
