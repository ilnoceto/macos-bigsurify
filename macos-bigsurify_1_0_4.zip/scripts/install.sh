#!/bin/bash
# === macos-bigsurify INSTALLER ===
# Installa temi, icone, cursori, wallpaper dal pacchetto LOCALE (offline)
# Imposta tema, icone, cursori e avvia Plank come dock predefinito

set -e

BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG="$HOME/install_bigsurify.log"
echo "=== Avvio installazione: $(date) ===" > "$LOG"

echo
echo "== macos-bigsurify installer =="
echo "Sto installando temi, icone, cursori e wallpaper..."
echo

# Temi
if [ -d "$BASE_DIR/themes" ]; then
    mkdir -p ~/.themes
    cp -vr "$BASE_DIR/themes/"* ~/.themes/ 2>&1 | tee -a "$LOG"
else
    echo "Cartella themes NON trovata" | tee -a "$LOG"
fi
echo

# Icone
if [ -d "$BASE_DIR/icons" ]; then
    mkdir -p ~/.icons
    cp -vr "$BASE_DIR/icons/"* ~/.icons/ 2>&1 | tee -a "$LOG"
else
    echo "Cartella icons NON trovata" | tee -a "$LOG"
fi
echo

# Cursori
if [ -d "$BASE_DIR/cursors" ]; then
    mkdir -p ~/.icons
    cp -vr "$BASE_DIR/cursors/"* ~/.icons/ 2>&1 | tee -a "$LOG"
else
    echo "Cartella cursors NON trovata" | tee -a "$LOG"
fi
echo

# Wallpaper
if [ -d "$BASE_DIR/wallpapers" ]; then
    mkdir -p ~/Immagini
    cp -vr "$BASE_DIR/wallpapers/"* ~/Immagini/ 2>&1 | tee -a "$LOG"
else
    echo "Cartella wallpapers NON trovata" | tee -a "$LOG"
fi
echo

echo "Temi, icone, cursori e wallpaper installati!"
echo "Consulta la guida nella cartella per configurare tutto."
echo "Log dettagliato: $LOG"
echo

# Mostra pagina donazioni PayPal (opzionale)
if [ -f "$BASE_DIR/paypal_donation_bilingual.html" ]; then
    nohup xdg-open "$BASE_DIR/paypal_donation_bilingual.html" >/dev/null 2>&1 &
fi

echo
echo "== Imposto configurazione desktop di default =="
gsettings set org.cinnamon.desktop.interface gtk-theme "WhiteSur-Light"
gsettings set org.cinnamon.desktop.interface icon-theme "WhiteSur"
gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
gsettings set org.cinnamon.desktop.wm.preferences theme "WhiteSur-Light"
echo "Configurazione desktop applicata."
echo

echo "== Avvio e abilitazione Plank come dock predefinito =="
nohup plank >/dev/null 2>&1 &

AUTOSTART_DIR="$HOME/.config/autostart"
mkdir -p "$AUTOSTART_DIR"

PLANK_DESKTOP_FILE="$AUTOSTART_DIR/plank.desktop"

if [ ! -f "$PLANK_DESKTOP_FILE" ]; then
    cat > "$PLANK_DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Exec=plank
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
Name=Plank
Comment=Start Plank dock at login
EOF
    echo "Plank abilitato all’avvio."
else
    echo "Plank è già abilitato all’avvio."
fi
echo

echo "Installazione terminata."
echo "Premi INVIO per chiudere questa finestra..."
read

