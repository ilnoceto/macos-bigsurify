#!/bin/bash
# Imposta automaticamente tema e icone in base alla configurazione desiderata

gsettings set org.cinnamon.desktop.interface gtk-theme "WhiteSur-Light"
gsettings set org.cinnamon.desktop.interface icon-theme "WhiteSur"
gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
gsettings set org.cinnamon.desktop.wm.preferences theme "WhiteSur-Light"

echo "Tema, icone e cursore impostati! Ricarica Cinnamon se necessario."

