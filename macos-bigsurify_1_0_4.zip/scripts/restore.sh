#!/bin/bash
# Ripristina tema, icone, cursori, reset dock Cinnamon e disattiva Plank

gsettings set org.cinnamon.desktop.interface gtk-theme "Mint-L"
gsettings set org.cinnamon.desktop.interface icon-theme "Mint-L"
gsettings set org.cinnamon.desktop.interface cursor-theme "Bibata-Modern-Classic"
gsettings set org.cinnamon.desktop.wm.preferences theme "Mint-L"

# Reset configurazione dock Cinnamon (dock predefinito)
gsettings reset-recursively org.cinnamon.dock

# Chiude Plank se è in esecuzione
pkill plank || true

# Disabilita Plank all’avvio (se è abilitato tramite autostart)
AUTOSTART_DIR="$HOME/.config/autostart"
PLANK_DESKTOP_FILE="plank.desktop"

if [ -f "$AUTOSTART_DIR/$PLANK_DESKTOP_FILE" ]; then
    mv "$AUTOSTART_DIR/$PLANK_DESKTOP_FILE" "$AUTOSTART_DIR/$PLANK_DESKTOP_FILE.disabled"
    echo "Plank disabilitato all'avvio."
fi

echo "Tema, cursori, dock Cinnamon ripristinati e Plank disattivato."

