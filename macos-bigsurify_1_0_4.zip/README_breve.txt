macos-bigsurify
Trasforma Linux Mint Cinnamon in macOS Big Sur

100% OFFLINE: non serve internet! Tutto incluso nella cartella.

Come si usa?
1. Estrai lo zip macos-bigsurify_1_0_4.zip dove vuoi (es. Scrivania).
2. Apri il terminale nella cartella scripts/.
3. Installa temi, icone, cursori e wallpaper con:
   ./install.sh
4. Applica subito lo stile macOS con:
   ./set-theme.sh
   (se non vedi subito l’effetto: riavvia la sessione o premi Alt+F2, digita r, dai invio)
5. Per tornare al tema Mint originale:
   ./restore.sh
6. Guarda la README.md per la guida completa.
   Script extra e utility si trovano sempre in scripts/.

Requisiti
- Consigliato: Linux Mint (Cinnamon)
- Per altri desktop: può funzionare ma non è garantito
- Pacchetti (già presenti su Mint, ma in caso di errore):
  sudo apt install git gtk2-engines-murrine gtk2-engines-pixbuf

Contenuto del pacchetto
- themes/ — Temi WhiteSur (dark, light, hdpi...)
- icons/ — Icone Papirus, WhiteSur, ecc.
- cursors/ — Cursori Apple
- wallpapers/ — Sfondi in stile macOS
- scripts/ — Script di installazione, restore, utility, Python
- python_env/ — Ambiente Python pronto (opzionale)
- doc/ — Documentazione extra (opzionale)
- README.md, LICENSE, CHANGELOG.md, paypal_donation_bilingual.html

Donazioni
Se vuoi supportare il progetto, puoi donare tramite PayPal:
https://www.paypal.com/donate/?business=GUT5D3NGL4QFA

Credits:
- WhiteSur themes by vinceliuice.
- Papirus icons by PapirusDevelopmentTeam.
- Cursori Apple by ful1e5.
- Personalizzazione, guida e script di Giovanni.
- Powered by ChatGPT/OpenAI.

🇬🇧 Quick English Guide
- Unzip macos-bigsurify_1_0_4.zip anywhere (e.g. Desktop).
- Open terminal in the scripts/ folder.
- Install themes, icons, cursors and wallpapers with:
  ./install.sh
- Apply macOS style instantly with:
  ./set-theme.sh
  (if you don’t see changes, log out and back in or press Alt+F2, type r, press enter)
- Restore Mint default theme:
  ./restore.sh
- Check README.md for full guide.
- Extra scripts/utilities always in scripts/.

macos-bigsurify © 2025 Giovanni | Released under MIT + Personal License
